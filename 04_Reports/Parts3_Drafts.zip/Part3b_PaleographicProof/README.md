
# Phase 3b — Computational Paleography (Execution Guide)

## Data layout (drop images here)
```
Part3b_PaleographicProof/
  data/
    voynich/    # Beinecke scans cropped to text lines or words (png/jpg)
    ragusan/    # Vinodol/Glagolitic exemplars
    venetian/   # Commemoriali/Gothic cursive exemplars
```

## How to run
1) Install packages from `requirements.txt` (local env).
2) Place images into the `data/` subfolders.
3) Run: `python paleography_pipeline_scaffold.py`
4) Outputs will appear under `artifacts/`:
   - `features_with_clusters.csv` (HOG + geom features + cluster ids)
   - `overlap_stats.json` (cluster composition + overlap metrics)

## Metrics
- `VM_Ragusan_overlap`: sum of min-shares across clusters for Voynich vs Ragusan glyphs.
- `VM_Venetian_overlap`: same vs Venetian.
Higher overlap implies stronger visual kinship.

## Notes
- Binarization uses Otsu threshold; tune min/max component area for glyph extraction.
- KMeans `k=60` by default; evaluate stability with k ∈ {40, 60, 80} and bootstraps.

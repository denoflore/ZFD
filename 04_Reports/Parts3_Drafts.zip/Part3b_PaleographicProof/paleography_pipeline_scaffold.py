
# Phase 3b — Computational Paleography Pipeline (Scaffold)
# Purpose: Extract glyphs from manuscript images, compute shape features, cluster,
# and quantify overlap between Voynich and Ragusan/Venetian hands.
#
# Inputs (expected folder layout):
#   data/
#     voynich/*.png|*.jpg   # page or line images (binary/greyscale ok)
#     ragusan/*.png|*.jpg   # e.g., Vinodol/Glagolitic exemplars
#     venetian/*.png|*.jpg  # Venetian Commemoriali exemplars
#
# Outputs:
#   artifacts/
#     glyph_crops/{set}/...          # cropped glyph images
#     features/{set}_features.csv    # feature vectors per glyph
#     clustering/kmeans_labels.csv   # cluster labels for all glyphs
#     stats/cross_set_overlap.json   # overlap + bootstraps
#
# Packages:
#   numpy, pandas, scikit-image, scikit-learn, opencv-python, matplotlib

import os, glob, json, numpy as np, pandas as pd
from skimage import io, filters, measure, morphology, feature, color, exposure
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

RNG_SEED = 1337

def binarize(img):
    if img.ndim == 3:
        img = color.rgb2gray(img)
    img = exposure.rescale_intensity(img)
    thr = filters.threshold_otsu(img)
    return (img < thr).astype('uint8')  # ink as 1

def extract_glyphs(img_bin, min_area=25, max_area=2000):
    # Label connected components and crop glyphs
    labeled = measure.label(img_bin, connectivity=2)
    props = measure.regionprops(labeled)
    crops = []
    for p in props:
        if min_area <= p.area <= max_area:
            minr, minc, maxr, maxc = p.bbox
            crop = img_bin[minr:maxr, minc:maxc]
            crops.append(crop)
    return crops

def hog_features(img_bin, pixels_per_cell=(8,8), cells_per_block=(2,2)):
    # Pad to at least 16x16 for HOG stability
    h, w = img_bin.shape
    H = max(h, 16); W = max(w, 16)
    canvas = np.zeros((H, W), dtype='uint8')
    y = (H - h)//2; x = (W - w)//2
    canvas[y:y+h, x:x+w] = img_bin
    # HOG
    vec = feature.hog(canvas, pixels_per_cell=pixels_per_cell, cells_per_block=cells_per_block, feature_vector=True)
    # Geom features
    aspect = w / h if h > 0 else 0.0
    ink = img_bin.sum() / (h*w) if h*w > 0 else 0.0
    return np.concatenate([vec, np.array([aspect, ink])])

def build_feature_table(img_paths, label):
    rows = []
    for path in img_paths:
        img = io.imread(path)
        img_bin = binarize(img)
        crops = extract_glyphs(img_bin)
        for i, c in enumerate(crops):
            feat = hog_features(c)
            rows.append({
                "set": label,
                "src": os.path.basename(path),
                "glyph_id": f"{os.path.basename(path)}#{i}",
                "f": feat
            })
    # explode into columns
    if not rows:
        return pd.DataFrame(columns=["set","src","glyph_id"])
    # infer length
    L = len(rows[0]["f"])
    df = pd.DataFrame([{"set":r["set"], "src":r["src"], "glyph_id": r["glyph_id"], **{f"f{i}":r["f"][i] for i in range(L)}} for r in rows])
    return df

def cluster_and_overlap(df):
    # Stack features
    feats = df[[c for c in df.columns if c.startswith("f")]].values
    scaler = StandardScaler()
    X = scaler.fit_transform(feats)
    k = 60  # target number of shape clusters (tunable)
    km = KMeans(n_clusters=k, random_state=RNG_SEED, n_init=10)
    labels = km.fit_predict(X)
    df["cluster"] = labels
    return df, km

def overlap_stats(df):
    # Compute distribution of sets within clusters and cross-set overlaps
    clusters = df["cluster"].unique()
    out = {}
    for cl in clusters:
        sub = df[df["cluster"]==cl]["set"].value_counts(normalize=True).to_dict()
        out[int(cl)] = sub
    # Overall VM-vs-Ragusan overlap: sum over clusters of min-share(VM, Ragusan)
    def overlap_of(a,b):
        s = 0.0
        for cl, shares in out.items():
            s += min(shares.get(a,0.0), shares.get(b,0.0))
        return s
    metrics = {
        "VM_Ragusan_overlap": overlap_of("voynich","ragusan"),
        "VM_Venetian_overlap": overlap_of("voynich","venetian")
    }
    return {"cluster_mix": out, "metrics": metrics}

def run(data_dir, artifacts_dir):
    os.makedirs(artifacts_dir, exist_ok=True)
    sets = {"voynich":"voynich","ragusan":"ragusan","venetian":"venetian"}
    fps = {k: sorted(glob.glob(os.path.join(data_dir, v, "*.*"))) for k,v in sets.items()}
    # Build features
    frames = []
    for label, paths in fps.items():
        if not paths:
            continue
        frames.append(build_feature_table(paths, label))
    if not frames:
        raise SystemExit("No input images found. Expected data/voynich, data/ragusan, data/venetian.")
    df = pd.concat(frames, ignore_index=True)
    # Cluster and compute overlap
    dfc, km = cluster_and_overlap(df)
    # Save features+labels
    feats_csv = os.path.join(artifacts_dir, "features_with_clusters.csv")
    dfc.to_csv(feats_csv, index=False)
    # Overlap stats
    stats = overlap_stats(dfc)
    with open(os.path.join(artifacts_dir, "overlap_stats.json"), "w") as f:
        json.dump(stats, f, indent=2)
    return feats_csv

if __name__ == "__main__":
    run("data", "artifacts")
